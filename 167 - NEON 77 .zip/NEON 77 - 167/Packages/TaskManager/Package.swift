// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TaskManager",
    platforms: [.iOS(.v16)],
    products: [
        .library(name: "TaskManager", targets: ["TaskManager"])
    ],
    targets: [
        .target(name: "TaskManager")
    ]
)
