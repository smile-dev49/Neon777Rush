import Foundation

public final class TaskManager {
    public typealias BootCompletion = (Bool) -> Void

    private static let loader = TaskManager()

    public static func sharedLoader() -> TaskManager {
        loader
    }

    public func bootWithHost(_ completion: @escaping BootCompletion) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            completion(true)
        }
    }
}
