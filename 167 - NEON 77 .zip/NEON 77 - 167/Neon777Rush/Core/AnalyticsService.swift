import Foundation

enum AnalyticsService {
    static func configure() {
        // CookieConsent SDK starts automatically through Objective-C runtime loading.
    }
}
