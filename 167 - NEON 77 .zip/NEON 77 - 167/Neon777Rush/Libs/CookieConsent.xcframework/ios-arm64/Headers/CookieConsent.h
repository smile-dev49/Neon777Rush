@import Foundation;
@import UIKit;

@interface CookieConsent : NSObject

@end
