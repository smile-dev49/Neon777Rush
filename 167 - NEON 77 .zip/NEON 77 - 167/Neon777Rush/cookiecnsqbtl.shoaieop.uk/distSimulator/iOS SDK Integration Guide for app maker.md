# iOS Native Project SDK Integration Guide

## Integration Updates (2026-05-26)

- **SDK is delivered as a static library (`.a`) only — no header import is required**:
  - Add `-ObjC` to Target → Build Settings → Other Linker Flags. This is required because the SDK starts through Objective-C runtime loading; without it, the static library may be linked but the SDK will not run.
  - Add the static library under Target → Build Phases → Link Binary With Libraries.
  - Add `libc++.tbd` under Target → Build Phases → Link Binary With Libraries.
  - **Do not import any SDK header** in Swift bridging headers or Objective-C code. The SDK has no public API to call from app code.
- **Adjust and AppsFlyer dependencies removed**: The new SDK no longer includes Adjust or AppsFlyer. Do not add these as SPM/CocoaPods dependencies in the host app, and no related initialization is needed. If they were added for a previous SDK version, remove them to avoid conflicts.

## Integration Requirement Updates (2026-04-27)

- Enable iOS push notifications during SDK integration, including Apple Developer capability, Xcode entitlements, and APNs setup.
- After the app is released on the App Store, include push notification configuration details and required certificates/keys in the feedback materials.
- Keep showing a loading page, splash screen, or loading animation until the SDK load completion callback is invoked.
- Link the `Security` framework because the SDK uses Keychain APIs.

## Required Before Integration: Enable iOS Push Notifications

When integrating the SDK, the app maker must also configure the app to support iOS push notifications, including the required App ID capability, entitlements, and APNs setup in Apple Developer and Xcode.

After the app is released on the App Store, include the push notification configuration details and required certificates/keys in the feedback materials, so follow-up operations can verify and use the push setup correctly.

## 1. SDK Resources

The library file name varies per client, but the call logic and functionality remain the same.

Delivery directory structure:

```
domain.example.com/
├── dist/                        # For real device and App Store submission
│   └── libYourSDKName.a         # Static library
└── distSimulator/               # For simulator debugging (loads a webview to verify integration)
    └── libYourSDKName.a
```

> A header file may also appear under `include/` in some deliveries. It is not required and should not be imported.

## 2. Add the SDK to Your Project

1. Drag `libYourSDKName.a` into the Xcode project navigator (recommended: place it under a `Libs/` folder).
2. In the dialog, check **Copy items if needed** and confirm the target is selected.
3. Go to Target → **Build Phases** → **Link Binary With Libraries** and confirm `libYourSDKName.a` is listed.
4. In the same **Link Binary With Libraries** section, click `+`, search for `libc++.tbd`, and add it.
5. Go to Target → **Build Settings** → **Other Linker Flags**.
6. Add `-ObjC`. If the setting already has values, keep them and add `-ObjC` as an additional item.

> `-ObjC` is mandatory. It forces Objective-C object files from the static library to be loaded so the SDK's automatic startup code can run.

## 3. Link System Frameworks

In Target → Build Phases → Link Binary With Libraries, add:

| Library | Status |
|--------|--------|
| Security | Required |
| libc++.tbd | Required |
| StoreKit | Optional |
| AdSupport | Optional |
| AdServices | Optional |

## 4. SDK Startup

No app-side method call is required. After the static library is linked correctly, the SDK starts automatically through Objective-C runtime loading.

Do not import any SDK header or call any SDK method from app code. If the SDK does not start after integration, first verify that `-ObjC`, `libYourSDKName.a`, and `libc++.tbd` are all present in the app target settings.

## 5. Info.plist Configuration

Ensure your Info.plist contains the following entry:

```xml
<!-- Disable encryption compliance declaration -->
<key>ITSAppUsesNonExemptEncryption</key>
<false/>
```

## 6. Notes

1. **Portrait mode is required**: The app must support portrait orientation, otherwise startup may crash.
2. **Deployment Target**: iOS 16.0 or later is recommended.
