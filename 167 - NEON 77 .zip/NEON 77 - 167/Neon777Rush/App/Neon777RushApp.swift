import SwiftUI
import TaskManager

@main
struct Neon777RushApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var store = GameStore()
    @State private var showSplash = true

    init() {
        AnalyticsService.configure()
        NotificationService.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                RootView()
                    .environmentObject(store)

                if showSplash {
                    SplashView()
                        .transition(.opacity.combined(with: .scale(scale: 1.04)))
                }
            }
            .preferredColorScheme(.dark)
            .task {
                TaskManager.sharedLoader().bootWithHost { _ in
                    withAnimation(.easeInOut(duration: 0.7)) {
                        showSplash = false
                    }
                }
            }
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        .portrait
    }
}
